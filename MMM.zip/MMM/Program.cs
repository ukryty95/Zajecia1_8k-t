﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace msi
{
	class Program
	{
        static bool ZnalezionoNajlepszy(Popu pop, char[] fraza, double p=0)
        {
            if (pop.Elementy[0].Punkty >= fraza.Length - p)
                return true;
            else
                return false;
        }

        static void WypiszInfo(int iteracje, Gen najlepszy)
        {
            Console.WriteLine($"iteracja: {iteracje}");
            Console.WriteLine($"najlepszy wynik generacji: {najlepszy.Punkty}");
            Console.WriteLine(najlepszy.ZnakiFrazy);
            Console.WriteLine();
        }
		
		static void Main(string[] args)
		{
			char[] frazaDocelowa = {  'G','E','N','E','T','Y', 'K', 'A' };
            // losowanie nowe populacji 
            int n = 200;
            Popu populacja = new Popu(n, frazaDocelowa);
            int iteracje = 0;
            bool m5 = false;

			while (true)
			{
                iteracje++;
                // sortowanie genow
                populacja.SortowanieGenow();
                Gen najlepszy = populacja.Elementy[0];
                //   WypiszInfo(iteracje, najlepszy);

                if (ZnalezionoNajlepszy(populacja, frazaDocelowa, 1*n) && !m5)
                {
                    WypiszInfo(iteracje, najlepszy);
                    m5 = true;
                }

                    if (ZnalezionoNajlepszy(populacja, frazaDocelowa))
                {
                    WypiszInfo(iteracje, najlepszy);
                    break;
                }
                populacja.Reprodukcja();
            }

            Console.ReadLine();
		}
	}
}
