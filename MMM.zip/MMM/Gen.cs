﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace msi
{
	class Gen
	{
		public char[] ZnakiFrazy { get; set; }
		public int Punkty { get; set; }
		public static Random rand = new Random();

		public Gen(int PhraseLength)
		{
			List<char> PhraseCharList = new List<char>();

			for (int i = 0; i < PhraseLength; i++)
			{
				PhraseCharList.Add(RandomLetter());
			}

			ZnakiFrazy = PhraseCharList.ToArray();
		}

		public static char RandomLetter()
		{
			string chars = "QWERTYUIOPASDFGHJKLZXCVBNM ";

			int num = rand.Next(0, chars.Length - 1);
			return chars[num];
		}

	}
}
