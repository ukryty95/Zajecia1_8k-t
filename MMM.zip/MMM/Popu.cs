﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace msi
{
	class Popu
	{
		public int rozmiarPopulacji { get; set; }

		public Gen[] Elementy { get; set; }

		public char[] FrazaDocelowa { get; set; }

		public Popu(int rp, char[] frazaDocelowa)
		{
			FrazaDocelowa = frazaDocelowa;
			rozmiarPopulacji = rp;
			Elementy = new Gen[rozmiarPopulacji];

			for (int i = 0; i < rozmiarPopulacji; i++)
			{
				Elementy[i] = new Gen(frazaDocelowa.Length);
			}
		}

		public void SortowanieGenow()
        {
			for (int i = 0; i < rozmiarPopulacji; i++)
			{
                OcenaGenu(Elementy[i]);
			}
            Elementy = Elementy.OrderByDescending(x => x.Punkty).ToArray();
		}

        private void OcenaGenu(Gen e)
        {
            for (int j = 0; j < FrazaDocelowa.Length; j++)
            {
                if (e.ZnakiFrazy[j].Equals(FrazaDocelowa[j]))
                    e.Punkty++;
            }
        }

		public void Reprodukcja()
		{
			Elementy = Elementy.OrderByDescending(element => element.Punkty).ToArray();
			var rnd = Gen.rand;

			var NoweElementy = new Gen[rozmiarPopulacji];
			for (int i = 0; i < rozmiarPopulacji; i++)
			{
                // losujemy 2 elementy spośród najelpszych 10% obecnej populacji
                Gen A = Elementy[rnd.Next(0, rozmiarPopulacji / 10)];
                Gen B = Elementy[rnd.Next(0, rozmiarPopulacji / 10)];
                // tworzymy nowy element krzyzujac z 2 wylosowanymi elementami
                NoweElementy[i] = CrossoverTwoElements(A, B);
                // mutujemy nowo powstały element
				Mutacja(NoweElementy[i]);
			}
            // zastepuje stara generacje nowa generacja
			Elementy = NoweElementy;
		}

		private Gen CrossoverTwoElements(Gen pierwszyElement, Gen drugiElement)
		{
			var rnd = Gen.rand;

			var dziecko = new Gen(pierwszyElement.ZnakiFrazy.Length);
			for (int i = 0; i < pierwszyElement.ZnakiFrazy.Length; i++)
			{
				if (rnd.NextDouble() < 0.5)
					dziecko.ZnakiFrazy[i] = pierwszyElement.ZnakiFrazy[i];
				else
					dziecko.ZnakiFrazy[i] = drugiElement.ZnakiFrazy[i];

			}
			return dziecko;
		}

        private void Mutacja(Gen element)
        {
            var rnd = new Random();

            for (int i = 0; i < element.ZnakiFrazy.Length; i++)
            {
                if (rnd.NextDouble() < 0.005)
                    element.ZnakiFrazy[i] = Gen.RandomLetter();
            }
        }
    }
}
